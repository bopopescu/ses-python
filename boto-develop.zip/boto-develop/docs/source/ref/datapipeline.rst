.. _ref-datapipeline:

=============
Data Pipeline
=============

boto.datapipeline
-----------------

.. automodule:: boto.datapipeline
   :members:
   :undoc-members:

boto.datapipeline.layer1
------------------------

.. automodule:: boto.datapipeline.layer1
   :members:
   :undoc-members:

boto.datapipeline.exceptions
----------------------------

.. automodule:: boto.datapipeline.exceptions
   :members:
   :undoc-members:
