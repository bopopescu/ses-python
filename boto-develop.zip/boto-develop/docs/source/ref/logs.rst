.. _ref-logs:

===============
CloudWatch Logs
===============

boto.logs
---------------

.. automodule:: boto.logs
   :members:
   :undoc-members:

boto.logs.layer1
----------------------

.. automodule:: boto.logs.layer1
   :members:
   :undoc-members:

boto.logs.exceptions
--------------------------

.. automodule:: boto.logs.exceptions
   :members:
   :undoc-members:
